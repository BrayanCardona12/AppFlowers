package com.example.loginf2.navegation

import okio.ByteString.Companion.encode
import java.net.URLEncoder
import java.nio.charset.StandardCharsets


sealed class NavRoutes(val route: String) {
    object Home : NavRoutes("Pant1")
    object Regresar : NavRoutes("LoginScreen")

    object HomeP : NavRoutes("Home2")

    object Login : NavRoutes("LoginScreen")
    object Insertar : NavRoutes("AddMovie")


    object Flower1 : NavRoutes("Flower1")


    object Flower2 : NavRoutes("Flower2")


    object Flower3 : NavRoutes("Flower3/{nombre}/{description}/{url}/{img}") {
        fun createRoute(nombre:String, description:String, url:String, img:String):String {
            fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())

            return "Flower3/$nombre/$description/${url.encodeUrl()}/${img.encodeUrl()}"
        }
    }



    object Flower4 : NavRoutes("Flower4")




}









