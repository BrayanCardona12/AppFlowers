package com.example.loginf2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons

import androidx.compose.material.icons.filled.LocalFlorist

import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

import com.example.loginf2.navegation.NavRoutes


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Flower1(navController: NavController) {

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colors.secondary)
            ) {
                Text(
                    text = "SunFlower",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 34.sp,
                    color =  MaterialTheme.colors.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable{navController.navigate(NavRoutes.Flower1.route) }
                    ) {
                        Icon(imageVector = Icons.Default.LocalFlorist, contentDescription = null,  tint =  MaterialTheme.colors.primary)
                        Text(text = "MY GARDEN", color = MaterialTheme.colors.primary, fontWeight = FontWeight.Bold)
                    }
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.Flower2.route) }
                    ) {
                        Icon(imageVector = Icons.Default.LocalFlorist, contentDescription = "", tint =  Color.Black,)
                        Text(text = "PLANT LIST", color = Color.Black)
                    }
                }
            }
        }
    ) {
        Column(
            modifier = Modifier
                .background(MaterialTheme.colors.primaryVariant)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Your Garden is Empty", fontSize = 25.sp, textAlign = TextAlign.Center, color = Color.Black)
            Text(text = "ADD PLANT", modifier = Modifier.background( MaterialTheme.colors.onError).padding(10.dp).clickable {
                                navController.navigate(NavRoutes.Flower4.route)
            }, color = Color.Black)
        }
    }
}