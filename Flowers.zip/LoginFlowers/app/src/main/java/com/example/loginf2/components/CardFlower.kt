package com.example.loginf2.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.loginf2.models.Flowers
import com.example.loginf2.navegation.NavRoutes
import com.example.loginf2.ui.theme.Shapes

@Composable
fun CardFlower(datos:Flowers ,navController: NavController) {

Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(bottom = 5.dp, top = 5.dp)) {
    Column(
        modifier = Modifier
            .border(1.dp, Color.Transparent, Shapes.small)
            .width(170.dp)
            .clip(Shapes.small)
            .background(Color.White)
            .clickable {
                navController.navigate(
                    NavRoutes.Flower3.createRoute(
                        datos.nombre.toString(),
                        datos.descripcion.toString(),
                        datos.url.toString(),
                        datos.img.toString()
                    )
                )
            },
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = rememberAsyncImagePainter(datos.img),
            contentDescription = "photo_fruta",
            modifier = Modifier
                .size(100.dp)
        )

        Text(
            text = datos.nombre,
            modifier = Modifier
                .padding(10.dp)
                .background(Color.White),
            color = Color.Black,
            textAlign = TextAlign.Center
        )
    }
    
}


}