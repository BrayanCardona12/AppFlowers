package com.example.loginf2.models

data class Flowers(
    val img : String = "",
    val nombre:String = "",
    val url: String = "",
    val descripcion:String = ""

)
