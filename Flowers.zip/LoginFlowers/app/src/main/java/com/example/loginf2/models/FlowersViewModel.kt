package com.example.loginf2.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class FlowersViewModel: ViewModel() {
    private val _flowers = mutableStateOf<List<Flowers>>(emptyList())

    val flowers : State<List<Flowers>>
        get() = _flowers
    private val query = Firebase.firestore.collection("flowers")

    init {
        query.addSnapshotListener {
                value, _->
            if(value != null) {
                _flowers.value = value.toObjects()
            } // fin del if
        } // fin del addSnapshotListener
    } // fin del contructor init
} // fin de la clase

// Funciopn tipo Unit